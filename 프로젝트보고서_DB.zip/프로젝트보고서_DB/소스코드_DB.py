import psycopg2
import requests
import xml.etree.ElementTree as ET
from psycopg2 import sql
import urllib.parse

# 데이터베이스 연결 설정
def connect_db():
    try:
        conn = psycopg2.connect(
            host="localhost",
            port="5432",
            database="postgres",
            user="postgres",
            password="12345678"
        )
        return conn
    except Exception as e:
        print("Database connection error:", e)
        return None

# 테이블이 존재하지 않으면 생성하는 함수
def create_tables(conn):
    cursor = conn.cursor()
    try:
        # full_ingredients 테이블 생성
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS full_ingredients (
                ingredient_name VARCHAR(255) PRIMARY KEY,
                representive_ingredient_name VARCHAR(255) NOT NULL,
                carbohydrates FLOAT NOT NULL,
                protein FLOAT NOT NULL,
                fat FLOAT NOT NULL,
                calories FLOAT NOT NULL
            );
        """)

        # users 테이블 생성
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id VARCHAR(255) PRIMARY KEY,
                username VARCHAR(255) NOT NULL,
                password VARCHAR(255) NOT NULL,
                height FLOAT,
                weight FLOAT,
                age INT,
                gender VARCHAR(10)
            );
        """)

        # today_ingredients 테이블 생성
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS today_ingredients (
                    user_id VARCHAR(255) NOT NULL,
                    ingredient_name VARCHAR(255) NOT NULL,
                    carbohydrates FLOAT NOT NULL,
                    protein FLOAT NOT NULL,
                    fat FLOAT NOT NULL,
                    calories FLOAT NOT NULL,
                    intake FLOAT NOT NULL,
                    PRIMARY KEY (user_id, ingredient_name)
                );
        """)

        # ingredients 테이블 생성
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ingredients (
                ingredient_name VARCHAR(255) NOT NULL,
                user_id VARCHAR(255) NOT NULL,
                carbohydrates FLOAT NOT NULL,
                protein FLOAT NOT NULL,
                fat FLOAT NOT NULL,
                calories FLOAT NOT NULL,
                serving_size FLOAT NOT NULL,
                PRIMARY KEY (ingredient_name, user_id)
            );
        """)

        conn.commit()
    except Exception as e:
        print("테이블 생성 중 오류 발생:", e)
        conn.rollback()

def initialize_data(conn):
    cursor = conn.cursor()
    # full_ingredients 테이블 데이터 존재 여부 확인
    cursor.execute("SELECT COUNT(*) FROM full_ingredients")
    if cursor.fetchone()[0] == 0:
        print("API 데이터를 초기화합니다...")
        insert_ingredients_to_db(conn)

# full_ingredients 테이블에 데이터 삽입
def insert_ingredients_to_db(conn):
    cursor = conn.cursor()
    try:
        # API 요청 URL
        api_url = "http://api.data.go.kr/openapi/tn_pubr_public_nutri_material_info_api"
        service_key = "uchZ9pv3fQtRaV9eanF5a6qIdH5NDnvhJMVNIVf3Pm%2F0DkLsNgsa4JdQnuAB2hGanP%2BjCtj39A7hNWjApFvuqQ%3D%3D"
        num_of_rows = 100
        response_format = "xml"

        page_no = 1
        while True: 
            url = f"{api_url}?serviceKey={service_key}&pageNo={page_no}&numOfRows={num_of_rows}&type={response_format}"
            response = requests.get(url)
            if response.status_code != 200:
                break
            
            root = ET.fromstring(response.text)

            result_code = root.find(".//resultCode").text
            if result_code == "03":
                break

            # XML 구조에서 <item> 태그 찾기
            items = root.findall(".//item")
            for item in items:
                # 각 필드 값 추출
                ingredient_name = item.find("foodNm").text if item.find("foodNm") is not None else None
                representive_ingredient_name = item.find("foodLv4Nm").text if item.find("foodLv4Nm") is not None else None
                carbohydrates = item.find("chocdf").text if item.find("chocdf") is not None else None
                protein = item.find("prot").text if item.find("prot") is not None else None
                fat = item.find("fatce").text if item.find("fatce") is not None else None
                calories = item.find("enerc").text if item.find("enerc") is not None else None

                # 데이터 유효성 검사 및 변환
                if ingredient_name and representive_ingredient_name:
                    try:
                        carbohydrates = float(carbohydrates) if carbohydrates else 0.0
                        protein = float(protein) if protein else 0.0
                        fat = float(fat) if fat else 0.0
                        calories = float(calories) if calories else 0.0
                    except ValueError as e:
                        print(f"데이터 변환 오류: {e}")
                        continue

                    # 중복 데이터 체크
                    cursor.execute("""
                        SELECT COUNT(*) FROM full_ingredients WHERE ingredient_name = %s
                    """, (ingredient_name,))
                    if cursor.fetchone()[0] == 0:
                        # 데이터 삽입
                        try:
                            cursor.execute("""
                                INSERT INTO full_ingredients 
                                (ingredient_name, representive_ingredient_name, carbohydrates, protein, fat, calories)
                                VALUES (%s, %s, %s, %s, %s, %s)
                            """, (ingredient_name, representive_ingredient_name, carbohydrates, protein, fat, calories))
                            print(f"{ingredient_name} 추가 완료!")
                        except Exception as e:
                            print(f"데이터 삽입 중 오류 발생: {e}")
                    else:
                        print(f"{ingredient_name}은(는) 이미 존재합니다.")

            # 변경사항 커밋
            conn.commit()
            page_no += 1
        else:
            print(f"API 요청 실패: {response.status_code}")
    except Exception as e:
        print("데이터 삽입 중 오류 발생: ", e)
        conn.rollback()

# 로그인 기능
def login_user(conn):
    cursor = conn.cursor()
    print("\n로그인을 시작합니다.")
    user_id = input("아이디를 입력하세요: ")
    password = input("비밀번호를 입력하세요: ")
    
    # 사용자 정보 확인
    query = "SELECT username FROM users WHERE user_id = %s AND password = %s"
    cursor.execute(query, (user_id, password))
    user = cursor.fetchone()
    if user:
        print(f"로그인 성공! 반갑습니다, {user[0]}님.")
        return user_id
    else:
        print("아이디 또는 비밀번호가 올바르지 않습니다. 다시 시도해주세요.")
        return None

# 회원가입 기능
def register_user(conn):
    cursor = conn.cursor()
    print("\n회원가입을 시작합니다.")
    
    # 사용자 입력 받기
    user_id = input("아이디를 입력하세요: ")
    password = input("비밀번호를 입력하세요: ")
    username = input("사용자 이름을 입력하세요: ")
    
    try:
        height = float(input("키(cm)를 입력하세요 (예: 175): "))
        weight = float(input("몸무게(kg)를 입력하세요 (예: 70): "))
        age = int(input("나이를 입력하세요: "))
        gender = input("성별을 입력하세요 (남/여): ")
        
        # 성별 유효성 검사
        if gender not in ["남", "여"]:
            print("성별은 '남' 또는 '여'로 입력해주세요.")
            return
    except ValueError:
        print("오류: 올바른 숫자 형식의 값을 입력해주세요.")
        return

    # 아이디 중복 확인
    query = "SELECT COUNT(*) FROM users WHERE user_id = %s"
    cursor.execute(query, (user_id,))
    if cursor.fetchone()[0] > 0:
        print("이미 존재하는 아이디입니다. 다시 시도해주세요.")
        return

    # 새 사용자 삽입
    query = """
        INSERT INTO users (user_id, username, password, height, weight, age, gender) 
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    try:
        cursor.execute(query, (user_id, username, password, height, weight, age, gender))
        conn.commit()
        print("회원가입이 완료되었습니다!")
    except Exception as e:
        print("회원가입 중 오류 발생:", e)
        conn.rollback()
    finally:
        cursor.close()

# 로그인 후 메뉴
def display_menu():
    print("\n1: 키/몸무게 수정")
    print("2. 보유하고 있는 식품 확인하기")
    print("3. 식품 넣기")
    print("4: 섭취한 식품 입력하기")
    print("5. 결핍 영양소 확인하기")
    print("6. 종료")

def update_user_details(conn, user_id):
    cursor = conn.cursor()
    try:
        new_height = input("\n새로운 키(cm)를 입력하세요 (예: 175): ")
        new_weight = input("새로운 몸무게(kg)를 입력하세요 (예: 70): ")
        
        # 유효성 검사
        if not new_height.isdigit() or not new_weight.isdigit():
            print("올바른 숫자를 입력하세요.")
            return
        
        # 사용자 정보 업데이트
        query = """
            UPDATE users 
            SET height = %s, weight = %s 
            WHERE user_id = %s
        """
        cursor.execute(query, (float(new_height), float(new_weight), user_id))
        conn.commit()
        print("사용자 정보가 성공적으로 수정되었습니다!")
    except Exception as e:
        print("사용자 정보 수정 중 오류 발생:", e)
        conn.rollback()

def add_ingredient(conn, user_id):
    while True:
        print("\n1: 식품 검색하기")
        print("2: 식품 직접 입력하기")
        print("0: 뒤로 가기")
        choice = input("번호를 선택하세요: ")

        if choice == '1':
            search_and_add_ingredient(conn, user_id)
        elif choice == '2':
            direct_add_ingredient(conn, user_id)
        elif choice == '0':
            print("이전 메뉴로 돌아갑니다.")
            return
        else:
            print("올바른 번호를 입력해주세요.")

def search_and_add_ingredient(conn, user_id):
    cursor = conn.cursor()
    while True:
        print("\n넣을 식품을 입력하시오 (뒤로 가려면 0번을 입력하시오): ")
        ingredient_name = input().strip()

        if ingredient_name == '0':
            print("이전 메뉴로 돌아갑니다.")
            return

        # 검색 쿼리
        query = """
            SELECT representive_ingredient_name, carbohydrates, protein, fat, calories
            FROM full_ingredients
            WHERE representive_ingredient_name = %s
            LIMIT 1
        """
        cursor.execute(query, (ingredient_name,))
        result = cursor.fetchone()

        if result:
            print("식품의 양(g)을 입력하시오: ")
            try:
                serving_size = float(input())
            except ValueError:
                print("올바른 숫자를 입력하세요.")
                continue

            # 중복 확인 및 처리
            check_query = """
                SELECT serving_size
                FROM ingredients
                WHERE user_id = %s AND ingredient_name = %s
            """
            cursor.execute(check_query, (user_id, result[0]))
            existing = cursor.fetchone()

            if existing:
                # 중복된 경우 serving_size 업데이트
                update_query = """
                    UPDATE ingredients
                    SET serving_size = serving_size + %s
                    WHERE user_id = %s AND ingredient_name = %s
                """
                cursor.execute(update_query, (serving_size, user_id, result[0]))
                conn.commit()
                print("기존 식품에 양을 추가하였습니다.")
            else:
                # 새롭게 추가
                insert_query = """
                    INSERT INTO ingredients VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(insert_query, (result[0], user_id, result[1], result[2], result[3], result[4], serving_size))
                conn.commit()
                print("새로운 식품이 성공적으로 추가되었습니다.")
        else:
            print("음식 정보가 없습니다. 다시 시도하세요.")

def direct_add_ingredient(conn, user_id):
    cursor = conn.cursor()
    print("\n식품명을 입력하세요: ")
    ingredient_name = input().strip()

    print("100g 당 탄수화물의 양(g)을 입력하세요: ")
    carbohydrates = float(input())

    print("100g 당 단백질의 양(g)을 입력하세요: ")
    protein = float(input())

    print("100g 당 지방의 양(g)을 입력하세요: ")
    fat = float(input())

    print("100g 당 칼로리의 양(kcal)을 입력하세요: ")
    calories = float(input())

    print("식품의 양(g)을 입력하세요: ")
    serving_size = float(input())

    # 중복 확인 및 처리
    check_query = """
        SELECT serving_size
        FROM ingredients
        WHERE user_id = %s AND ingredient_name = %s
    """
    cursor.execute(check_query, (user_id, ingredient_name))
    existing = cursor.fetchone()

    if existing:
        # 중복된 경우 serving_size 업데이트
        update_query = """
            UPDATE ingredients
            SET serving_size = serving_size + %s
            WHERE user_id = %s AND ingredient_name = %s
        """
        cursor.execute(update_query, (serving_size, user_id, ingredient_name))
        conn.commit()
        print("기존 식품에 양을 추가하였습니다.")
    else:
        # 새롭게 추가
        insert_query = """
            INSERT INTO ingredients (user_id, ingredient_name, carbohydrates, protein, fat, calories, serving_size)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (user_id, ingredient_name, carbohydrates, protein, fat, calories, serving_size))
        conn.commit()
        print("새로운 식품이 성공적으로 추가되었습니다.")

def remove_ingredient(conn, user_id):
    cursor = conn.cursor()
    
    # 섭취한 식품과 양 입력받기
    ingredient_name = input("\n섭취한 식품을 기입하시오: ")
    try:
        amount_to_remove = float(input(f"{ingredient_name}의 섭취한 양을 입력하시오 (g): "))
    except ValueError:
        print("오류: 올바른 숫자를 입력해주세요.")
        return
    
    try:
        # today_ingredients에서 해당 식품 정보 가져오기
        cursor.execute("""
            SELECT intake 
            FROM today_ingredients 
            WHERE user_id = %s AND ingredient_name = %s
        """, (user_id, ingredient_name))
        today_result = cursor.fetchone()
        
        # ingredients 테이블에서 필요한 데이터 가져오기
        cursor.execute("""
            SELECT serving_size, carbohydrates, protein, fat, calories 
            FROM ingredients 
            WHERE user_id = %s AND ingredient_name = %s
        """, (user_id, ingredient_name))
        ingredients_result = cursor.fetchone()

        if not ingredients_result:
            print("오류: 보유하고 있지 않은 식품을 입력하였습니다.")
            return
        
        # 필요한 데이터 언패킹
        serving_size, carbohydrates, protein, fat, calories = ingredients_result
        
        # 데이터 타입 확인 및 변환
        serving_size = float(serving_size)
        
        if amount_to_remove > serving_size:
            print("오류: 섭취한 양이 현재 보유량보다 많습니다.")
            return
        
        # today_ingredients에 정보가 있는 경우
        if today_result:
            current_intake = float(today_result[0])  # 현재 섭취량
            
            if amount_to_remove == serving_size:
                new_intake = current_intake + amount_to_remove
                # ingredients 행 삭제
                cursor.execute("""
                    DELETE FROM ingredients
                    WHERE user_id = %s AND ingredient_name = %s
                """, (user_id, ingredient_name))
                # today_ingredients 업데이트
                cursor.execute("""
                    UPDATE today_ingredients
                    SET intake = %s
                    WHERE user_id = %s AND ingredient_name = %s
                """, (new_intake, user_id, ingredient_name))
            else:
                # today_ingredients 섭취량 감소
                new_serving_size = serving_size - amount_to_remove
                new_intake = current_intake + amount_to_remove
                cursor.execute("""
                    UPDATE ingredients
                    SET serving_size = %s
                    WHERE user_id = %s AND ingredient_name = %s
                """, (new_serving_size, user_id, ingredient_name))
                cursor.execute("""
                    UPDATE today_ingredients
                    SET intake = %s
                    WHERE user_id = %s AND ingredient_name = %s
                """, (new_intake, user_id, ingredient_name))
        else:
            new_serving_size = serving_size - amount_to_remove
            cursor.execute("""
                UPDATE ingredients
                SET serving_size = %s
                WHERE user_id = %s AND ingredient_name = %s
            """, (new_serving_size, user_id, ingredient_name))
            cursor.execute("""
                INSERT INTO today_ingredients
                (user_id, ingredient_name, carbohydrates, protein, fat, calories, intake)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (user_id, ingredient_name, carbohydrates, protein, fat, calories, amount_to_remove))

        conn.commit()
    except Exception as e:
        print(f"오류가 발생했습니다: {e}")
        conn.rollback()
    finally:
        cursor.close()

def view_ingredients(conn, user_id):
    cursor = conn.cursor()
    try:
        with conn.cursor() as cursor:
            query = """
                SELECT ingredient_name, serving_size
                FROM ingredients
                WHERE user_id = %s;
            """
            cursor.execute(query, (user_id,))
            ingredients = cursor.fetchall()

            if ingredients:
                print("\n가지고 있는 식품 목록:")
                for item in ingredients:
                    print(f"식품명: {item[0]}, 양: {item[1]}g")
            else:
                print("현재 섭취한 식품이 없습니다.")
    except Exception as e:
        print(f"Error retrieving ingredients: {e}")

def check_nutrient_deficiency(conn, user_id):
    try:
        with conn.cursor() as cursor:
            # 총 섭취량 계산 (today_ingredients 테이블 사용)
            query = """
                SELECT 
                    COALESCE(SUM(ti.carbohydrates * ti.intake / 100), 0) AS total_carbs,
                    COALESCE(SUM(ti.protein * ti.intake / 100), 0) AS total_protein,
                    COALESCE(SUM(ti.fat * ti.intake / 100), 0) AS total_fat,
                    COALESCE(SUM(ti.calories * ti.intake / 100), 0) AS total_calories
                FROM today_ingredients ti
                WHERE ti.user_id = %s;
            """
            cursor.execute(query, (user_id,))
            total_nutrients = cursor.fetchone()

            total_carbs, total_protein, total_fat, total_calories = total_nutrients

            # 사용자에게 확인할 영양소 선택
            print("\n확인하고 싶은 결핍 영양소를 입력하세요:")
            print("1. 탄수화물 2. 단백질 3. 지방 4. 칼로리")
            choice = input("번호를 입력하세요: ")

            if choice not in ['1', '2', '3', '4']:
                print("올바른 번호를 입력하세요.")
                return

            recommended_nutrients = calculate_recommended_nutrients(conn, user_id)

            nutrient_map = {
                "1": ("carbohydrates", total_carbs, recommended_nutrients["carbohydrates"]),
                "2": ("protein", total_protein, recommended_nutrients["protein"]),
                "3": ("fat", total_fat, recommended_nutrients["fat"]),
                "4": ("calories", total_calories, recommended_nutrients["calories"]),
            }

            if choice not in nutrient_map:
                print("올바른 번호를 입력하세요.")
                return

            nutrient_name, total_amount, recommended_amount = nutrient_map[choice]

            # 결핍량 계산
            deficiency = recommended_amount - total_amount
            if deficiency <= 0:
                print(f"\n{nutrient_name}의 하루 권장량을 모두 섭취하였습니다.")
                return

            print(f"\n{nutrient_name}이(가) {deficiency:.2f}g 모자랍니다.")

            # 결핍을 채우기 위한 식품 섭취량 계산
            query = """
                SELECT ingredient_name, {0}
                FROM ingredients
                WHERE user_id = %s;
            """.format(nutrient_name)
            cursor.execute(query, (user_id,))
            ingredients = cursor.fetchall()

            if not ingredients:
                print("섭취 가능한 식품이 없습니다.")
                return

            print(f"{nutrient_name}의 결핍을 채우기 위해 섭취해야 할 식품:")
            for ingredient in ingredients:
                food_name, nutrient_value = ingredient
                if nutrient_value > 0:
                    required_amount = (100 * deficiency) / nutrient_value
                    print(f"{food_name}: {required_amount:.2f}g")

    except Exception as e:
        print(f"에러가 발생하였습니다: {e}")

def calculate_recommended_nutrients(conn, user_id):
    cursor = conn.cursor()
    query = """
            SELECT height, weight, age, gender
            FROM users
            WHERE user_id = %s
        """
    cursor.execute(query, (user_id,))
    result = cursor.fetchone()

    height = result[0]
    weight = result[1]
    age = result[2]
    gender = result[3]

    # BMR 계산
    if gender == "남":
        bmr = 10 * weight + 6.25 * height - 5 * age + 5
    elif gender == "여":
        bmr = 10 * weight + 6.25 * height - 5 * age - 161
    else:
        raise ValueError("성별을 다시 입력하시오.")
    
    # TDEE 계산
    activity_multipliers = {
        1: 1.2,
        2: 1.375,
        3: 1.55,
        4: 1.725,
        5: 1.9
    }

    strength = input('\n활동 수준을 입력하시오 \n1. 매우 적은 활동(앉아서 생활) \n2. 가벼운 활동(가벼운 운동) \n3. 중간 활동(주 3~5회 운동) \n4. 활발한 활동(매일 운동) \n5. 매우 활발한 운동(격렬한 운동)\n')

    if (strength == '1'):
        tdee = bmr * 1.2
    elif (strength == '2'):
        tdee = bmr * 1.375
    elif (strength == '3'):
        tdee = bmr * 1.55
    elif (strength == '4'):
        tdee = bmr * 1.725
    elif (strength == '5'):
        tdee = bmr * 1.9
    else:
        raise ValueError("잘못된 숫자를 기입했습니다.")

    # 권장 섭취량 계산
    recommended_nutrients = {
        "carbohydrates": tdee * 0.5 / 4,  # g
        "protein": tdee * 0.2 / 4,        # g
        "fat": tdee * 0.3 / 9,            # g
        "calories": tdee                  # kcal
    }

    return recommended_nutrients


# 메인 실행 함수
def main():
    conn = connect_db()
    if not conn:
        return

    try:
        # 테이블이 존재하지 않으면 생성
        create_tables(conn)

        # 초기 데이터 설정
        initialize_data(conn)

        user_id = None
        while True:
            if not user_id:
                print("\n1: 로그인\n2: 회원가입\n3: 종료")
                choice = input("원하는 기능에 해당되는 번호를 입력하시오: ")
                if choice == '1':
                    user_id = login_user(conn)
                elif choice == '2':
                    register_user(conn)
                elif choice == '3':
                    print("프로그램을 종료합니다.")
                    break
                else:
                    print("올바른 번호를 입력해주세요.")
            else:
                display_menu()
                choice = input("번호를 선택하세요: ")
                if choice == '1':
                    update_user_details(conn, user_id) # 키/몸무게 수정
                elif choice == '2':
                    view_ingredients(conn, user_id) # 식품 목록 보기
                elif choice == '3':
                    add_ingredient(conn, user_id) # 식품 넣기
                elif choice == '4':
                    remove_ingredient(conn, user_id) # 식품 빼기
                elif choice == '5':
                    check_nutrient_deficiency(conn, user_id) # 결핍 영양소 확인하기
                elif choice == '6':
                    print("프로그램을 종료합니다.")
                    break
                else:
                    print("올바른 번호를 입력해주세요.")
    except Exception as e:
        print(f"오류가 발생했습니다: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    main()

